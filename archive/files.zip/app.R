# =====================================================================
# Ctesiphus Expedition - campaign manager (Shiny, mobile-first)
# ---------------------------------------------------------------------
# Entry point. Everything the facilitator and players need is in the GUI;
# no R console use is required. Flows:
#   - Setup:       create a new campaign (map + players + bases) or pick one
#   - Pre-game:    your hex, its location + condition rules, killzone
#   - Post-game:   submit your battle result, then a campaign action
#   - Facilitator: resolve the current phase, advance the round
#
# DB credentials come from .Renviron (CTES_*). If the database is
# unreachable the app still launches and says so.
# =====================================================================

library(shiny); library(bslib); library(dplyr); library(readr)

for (f in c("dice.R","hexmap.R","exploration_tables.R","explore.R","actions.R",
            "movement.R","battle.R","threat.R","orchestrator.R","map_selection.R",
            "persist.R","lifecycle.R"))
  source(file.path("R", f), local = FALSE)
source("setup_campaign.R", local = FALSE)            # seed_campaign(), apply_schema()

# --- helpers -----------------------------------------------------------------
rule_for <- function(code) {
  if (is.null(code) || is.na(code)) return("Unexplored.")
  for (tb in list(surface_location_table, tomb_location_table,
                  surface_condition_table, tomb_condition_table)) {
    hit <- tb[tb$code == code, ]; if (nrow(hit)) return(paste0(hit$name[1], " - ", hit$rules[1]))
  }
  code
}
killzone_for <- function(type) if (identical(type, "tomb"))
  "Tomb World / close-quarters killzone." else "Volkus (open) killzone."
surface_hexes_of <- function(map_id) {
  m <- readr::read_csv(file.path("inst", "maps", sprintf("map%d.csv", map_id)),
                       show_col_types = FALSE)
  sort(m$hex_number[m$type == "surface"])
}

# --- theme -------------------------------------------------------------------
theme <- bs_theme(
  version = 5, bg = "#0b0e0d", fg = "#cfe8d8",
  primary = "#36e0a0", secondary = "#1c2622", warning = "#e0a44d",
  base_font = font_google("IBM Plex Sans"), heading_font = font_google("Chakra Petch"),
  "border-radius" = "0.15rem") |>
  bs_add_rules("
    body { background: radial-gradient(1200px 600px at 50% -10%, #14201b 0%, #0b0e0d 60%); }
    .card { border: 1px solid #1f2d27; box-shadow: 0 0 0 1px #0e1512 inset; }
    .threat { letter-spacing:.08em; text-transform:uppercase; color:#e0a44d; }
    .hex-tag { font-family:'Chakra Petch'; font-size:1.6rem; color:#36e0a0; }
    .pl-row { border-top:1px solid #1f2d27; padding-top:.5rem; margin-top:.5rem; }")

# --- UI ----------------------------------------------------------------------
ui <- page_navbar(
  title = "CTESIPHUS EXPEDITION", theme = theme, fillable = TRUE, id = "nav",
  sidebar = sidebar(open = "closed", width = 280,
    selectInput("campaign", "Campaign", choices = NULL),
    selectInput("team", "Your kill team", choices = NULL),
    uiOutput("cursor_badge")),

  nav_panel("Setup", icon = icon("flag-checkered"),
    card(card_header("New campaign"),
      textInput("season", "Season name", placeholder = "e.g. Summer 2026"),
      radioButtons("map_mode", "Board",
        c("Draw weighted by player count" = "draw", "Choose a specific map" = "choose")),
      conditionalPanel("input.map_mode == 'draw'",
        numericInput("draw_players", "Expected players", 4, 2, 6),
        numericInput("draw_seed", "Random seed (for an auditable draw)", 42, 1, 99999)),
      conditionalPanel("input.map_mode == 'choose'",
        selectInput("choose_map", "Map", c(
          "Map 1 - 26 hexes" = 1, "Map 2 - 33 hexes" = 2, "Map 3 - 36 hexes" = 3,
          "Map 4 - 37 hexes" = 4, "Map 5 - 52 hexes" = 5))),
      actionButton("set_map", "Set board & show bases", class = "btn-secondary w-100"),
      uiOutput("map_info")),
    uiOutput("players_card"),
    card(uiOutput("setup_actions"), verbatimTextOutput("setup_status"))),

  nav_panel("Pre-game", icon = icon("eye"),
    card(card_header("Where you stand"),
      div(class = "hex-tag", textOutput("hex_label", inline = TRUE)),
      uiOutput("killzone")),
    card(card_header("Location rule"), textOutput("loc_rule")),
    card(card_header("Condition rule"), textOutput("cond_rule"))),

  nav_panel("Post-game", icon = icon("dice"),
    card(card_header("Report your battle"),
      radioButtons("result", NULL,
        c("Win"="win","Draw"="draw","Loss"="loss","Bye"="bye"), inline = TRUE),
      numericInput("ops", "Enemy operatives incapacitated (weighted)", 0, min = 0),
      actionButton("submit_battle", "Submit result", class = "btn-primary w-100")),
    card(card_header("Activity"), verbatimTextOutput("player_log"))),

  nav_panel("Facilitator", icon = icon("gauge"),
    card(card_header("Round control"),
      uiOutput("phase_state"),
      layout_columns(
        actionButton("resolve", "Resolve current phase", class = "btn-warning"),
        actionButton("advance", "Advance / begin", class = "btn-primary"))),
    card(card_header("Resolution log"), verbatimTextOutput("facilitator_log")))
)

# --- server ------------------------------------------------------------------
server <- function(input, output, session) {
  rv <- reactiveValues(board = NULL, log = character(0), err = NULL,
                       campaign_id = NULL, setup_map = NULL, surface = NULL,
                       setup_msg = "")

  withCon <- function(fn) {
    tryCatch({ con <- db_connect(); on.exit(DBI::dbDisconnect(con)); fn(con) },
             error = function(e) { rv$err <- conditionMessage(e); NULL })
  }
  refresh <- function() {
    if (is.null(rv$campaign_id)) return(invisible())
    withCon(function(con) { rv$board <- load_board(con, rv$campaign_id); rv$err <- NULL })
  }
  load_campaigns <- function() withCon(function(con)
    DBI::dbGetQuery(con, "SELECT campaign_id, season_name FROM campaign ORDER BY campaign_id"))

  observeEvent(TRUE, {
    cs <- load_campaigns()
    if (!is.null(cs) && nrow(cs)) {
      updateSelectInput(session, "campaign",
        choices = setNames(cs$campaign_id, sprintf("%d - %s", cs$campaign_id, cs$season_name)))
      rv$campaign_id <- cs$campaign_id[1]; refresh()
    } else {
      nav_select("nav", "Setup")                 # no campaign yet -> Setup
    }
  }, once = TRUE)

  observeEvent(input$campaign, { rv$campaign_id <- as.integer(input$campaign); refresh() },
               ignoreInit = TRUE)
  observe({ req(rv$board); updateSelectInput(session, "team", choices = names(rv$board$teams)) })

  output$cursor_badge <- renderUI({
    if (!is.null(rv$err)) return(div(class = "threat", "DB offline"))
    req(rv$board)
    div(class = "threat",
        sprintf("Round %s - %s (%s)", rv$board$cursor$round, rv$board$cursor$phase,
                rv$board$cursor$status),
        br(), sprintf("Threat %d / %d", rv$board$threat, rv$board$max_threat))
  })

  # ---- Setup wizard ---------------------------------------------------------
  observeEvent(input$set_map, {
    mid <- if (input$map_mode == "choose") as.integer(input$choose_map) else {
      set.seed(input$draw_seed); as.integer(choose_map(input$draw_players)) }
    rv$setup_map <- mid
    rv$surface <- surface_hexes_of(mid)
    rv$setup_msg <- sprintf("Board set to map %d (%d surface hexes available for bases).",
                            mid, length(rv$surface))
  })

  output$map_info <- renderUI({
    if (is.null(rv$setup_map)) return(NULL)
    div(class = "text-secondary", sprintf("Map %d selected. Surface hexes: %s",
        rv$setup_map, paste(rv$surface, collapse = ", ")))
  })

  output$players_card <- renderUI({
    req(rv$setup_map)
    card(card_header("Players & bases"),
      numericInput("n_teams", "Number of teams", min(2, length(rv$surface)),
                   2, min(8, length(rv$surface))),
      uiOutput("player_rows"))
  })

  output$player_rows <- renderUI({
    req(rv$setup_map, input$n_teams)
    lapply(seq_len(input$n_teams), function(i) div(class = "pl-row",
      layout_columns(col_widths = c(4, 4, 2, 2),
        textInput(paste0("pname_", i), if (i==1) "Player" else NULL),
        textInput(paste0("tname_", i), if (i==1) "Team" else NULL),
        textInput(paste0("hndl_", i),  if (i==1) "Handle" else NULL),
        selectInput(paste0("base_", i), if (i==1) "Base hex" else NULL, choices = rv$surface))))
  })

  output$setup_actions <- renderUI(tagList(
    actionButton("create_campaign", "Create campaign", class = "btn-primary w-100"),
    if (!is.null(rv$campaign_id))
      actionButton("begin", "Begin campaign (open week 1)", class = "btn-success w-100 mt-2")))

  observeEvent(input$create_campaign, {
    if (!nzchar(input$season)) { rv$setup_msg <- "Enter a season name."; return() }
    if (is.null(rv$setup_map)) { rv$setup_msg <- "Set a board first."; return() }
    teams <- do.call(rbind, lapply(seq_len(input$n_teams), function(i) data.frame(
      player_name = input[[paste0("pname_", i)]], team_name = input[[paste0("tname_", i)]],
      login_handle = input[[paste0("hndl_", i)]],
      base_hex = as.integer(input[[paste0("base_", i)]]), stringsAsFactors = FALSE)))
    if (any(!nzchar(teams$player_name)) || any(!nzchar(teams$team_name)) || any(!nzchar(teams$login_handle))) {
      rv$setup_msg <- "Every team needs a player, team name, and handle."; return() }
    if (anyDuplicated(teams$base_hex)) { rv$setup_msg <- "Two teams share a base hex - bases must be distinct."; return() }

    res <- withCon(function(con)
      seed_campaign(con, season_name = input$season, teams = teams, map_id = rv$setup_map))
    if (is.null(res)) { rv$setup_msg <- paste("Create failed:", rv$err); return() }
    rv$campaign_id <- as.integer(res)
    cs <- load_campaigns()
    updateSelectInput(session, "campaign",
      choices = setNames(cs$campaign_id, sprintf("%d - %s", cs$campaign_id, cs$season_name)),
      selected = rv$campaign_id)
    refresh()
    rv$setup_msg <- sprintf("Created campaign %d on map %d with %d teams. Click 'Begin' to open week 1.",
                            rv$campaign_id, rv$setup_map, nrow(teams))
  })
  output$setup_status <- renderText(rv$setup_msg)

  # ---- Pre-game -------------------------------------------------------------
  team   <- reactive({ req(rv$board, input$team); rv$board$teams[[input$team]] })
  hexrow <- reactive({ b <- rv$board; b$map[b$map$hex_number == team()$hex, ] })
  output$hex_label <- renderText(sprintf("HEX %s", team()$hex))
  output$killzone  <- renderUI(div(class = "text-secondary", killzone_for(hexrow()$type)))
  output$loc_rule  <- renderText(rule_for(hexrow()$location_code))
  output$cond_rule <- renderText(rule_for(hexrow()$condition_code))

  # ---- Post-game ------------------------------------------------------------
  observeEvent(input$submit_battle, {
    req(rv$campaign_id, input$team)
    withCon(function(con) {
      rid <- DBI::dbGetQuery(con,
        "SELECT round_id FROM rounds WHERE campaign_id=$1 ORDER BY week_number DESC LIMIT 1",
        params = list(rv$campaign_id))$round_id
      DBI::dbExecute(con,
        "INSERT INTO battles (round_id, team_id, result, operatives_incap)
         VALUES ($1,$2,$3,$4) ON CONFLICT (round_id, team_id) DO UPDATE
           SET result=EXCLUDED.result, operatives_incap=EXCLUDED.operatives_incap",
        params = list(rid, as.integer(input$team), input$result, input$ops))
      rv$log <- c(rv$log, sprintf("Battle result '%s' recorded.", input$result))
    })
  })
  output$player_log <- renderText(paste(rev(tail(rv$log, 12)), collapse = "\n"))

  # ---- Facilitator ----------------------------------------------------------
  output$phase_state <- renderUI({
    if (!is.null(rv$err)) return(div(class="threat", paste("DB:", rv$err)))
    req(rv$board)
    tagList(div(class = "hex-tag", toupper(rv$board$cursor$phase)),
            div(class = "text-secondary",
                sprintf("Round %s, status %s", rv$board$cursor$round, rv$board$cursor$status)))
  })

  observeEvent(input$resolve, {
    req(rv$board); b <- rv$board; phase <- b$cursor$phase
    out <- switch(phase,
      movement = resolve_movement_phase(b, list()),
      battle   = resolve_battle_phase(b, list()),
      threat   = resolve_threat_phase(b),
      list(board = b, log = sprintf("Phase '%s' resolved from its submissions.", phase)))
    rv$board <- out$board; rv$log <- c(rv$log, out$log)
    withCon(function(con) {
      save_board(con, rv$campaign_id, out$board, log = out$log, phase = phase)
      mark_phase_resolved(con, rv$campaign_id); rv$board$cursor$status <- "resolved" })
  })

  observeEvent(c(input$advance, input$begin), {
    req(rv$campaign_id)
    withCon(function(con) { db_advance_phase(con, rv$campaign_id)
      rv$log <- c(rv$log, "Advanced phase.") })
    refresh()
  }, ignoreInit = TRUE)

  output$facilitator_log <- renderText(paste(rev(tail(rv$log, 20)), collapse = "\n"))
}

shinyApp(ui, server)
